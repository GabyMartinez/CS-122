import java.io.File;
import java.io.*;
import java.util.Scanner;

public class Task2 {

	public static void main(String[] args) {
		File input = new File("source.txt");
		String line;
		int num = 1;
		
		try {
			Scanner scan = new Scanner(input);
			PrintWriter output = new PrintWriter("destination.txt");
			while(scan.hasNext()) {
				line = scan.nextLine();
				System.out.println(line);
				
				output.println("Line "+ num++ + ": " + line);
			}
			output.close();
			
			
		}
		catch (FileNotFoundException e) {
			System.out.println("Input File not found\nDid you spell the file right? Try putting it in the root.");
			e.printStackTrace();
		}
	}

}
