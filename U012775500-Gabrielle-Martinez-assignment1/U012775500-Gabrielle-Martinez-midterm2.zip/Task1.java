import java.util.Scanner;

public class Task1 {
	public static void main(String[]arg) {
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter a word:");
		String input = scan.next();
		System.out.println(input + " has " + Task1.countX(input) + " X's");
		
		
	}
	public static int countX(String s) {
		//counts # of x's
		int numChar=0, index=0;
		
		//base case
		if(index == s.length())
			return numChar;
		
		else {
			System.out.println("Case: " + s.charAt(index));
			if(s.charAt(index)=='x') {
				numChar++;
				System.out.println("#x: "+numChar);
			}
			index++;
			countX(s.substring(index, s.length()));
			return numChar;
		}
		//return numChar;	
	}
}
