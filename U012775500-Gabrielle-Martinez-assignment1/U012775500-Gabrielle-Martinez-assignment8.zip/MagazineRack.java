// PP 13.2
public class MagazineRack {

	public static void main(String[] args) {
//	/*	
		MagazineList rack = new MagazineList();
		
		rack.add(new Magazine("Time"));
	//		System.out.println(rack);
		
		rack.add(new Magazine("Woodworking Today"));
		//	System.out.println(rack);
		
		rack.add(new Magazine("Communications of the ACM"));
		//	System.out.println(rack);
		
		rack.add(new Magazine("House and Garden"));
		//	System.out.println(rack);
		
		rack.add(new Magazine("GQ"));
			System.out.println(rack);
		
		rack.delete("Communications of the ACM");
		System.out.println(rack);
		
		rack.delete();
		System.out.println(rack);
	
//	*/	
		MagazineList rack2 = new MagazineList();
		
		rack2.insert(new Magazine("Hello Internet"));
		rack2.insert(new Magazine("Cortex"));
			System.out.println(rack2);
		rack2.insert(new Magazine("Welcome to Nightvale"));
			System.out.println(rack2);
		rack2.insert(new Magazine("Xray"));
			System.out.println(rack2);
	/* 
		Magazine mag = new Magazine("Hello Internet");
		Magazine mag2 = new Magazine("Cortex");
		if (mag.compareTo(mag2)<0)
	*/		
	}

}
