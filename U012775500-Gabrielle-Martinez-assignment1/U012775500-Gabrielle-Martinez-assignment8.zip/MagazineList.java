// PP 13.2
public class MagazineList { //linked list
	private MagazineNode list;
	
	public MagazineList() {
		list = null;
	}
	
	public void add(Magazine mag) {
		MagazineNode node = new MagazineNode(mag);
		MagazineNode current;
		
		if(list == null)
			list = node;
		else {
			current = list;
			while (current.next != null) 
				current = current.next;
			current.next = node;
		}
	}
	
	public void delete() {
		MagazineNode current=list;
		MagazineNode prev = list;
		if(list != null) { //find the end and set last node to null (last node has next==null)
			if(list.next==null)
				list=null;
			while (current.next != null) {
				prev = current;
				current = current.next;
			}
			prev.next = null;
		}
	}
	
	public void delete(String title) {
	//	MagazineNode node = new MagazineNode();
		MagazineNode current = list;
		MagazineNode prev = list;
		while(current != null) {
			if(title.equals(current.magazine.getTitle())) {
				prev.next = current.next;
				break;
			}
			prev = current;
			current = current.next;
		}
	}
	
	public void insert(Magazine mag) {
		MagazineNode node = new MagazineNode(mag);
		MagazineNode current=list, prev=list;
		
		if(list==null)
			list = node;
		else if(list.next==null) {
			if(mag.compareTo(current.magazine)<0) {
				node.next = current;
				list = node;
			}
			else if(mag.compareTo(current.magazine)>0) {
				current.next = node;
			}
		}
///*	
		else {
			while(current.next != null) {
				if(mag.compareTo(current.magazine)<0) {
					prev.next = node;
					node.next = current;
				}
				else if(mag.compareTo(current.magazine)>0) {
					node.next = current.next;
					current.next = node;
				}
				prev = current;
				current = current.next;
			} 
		}
//*/
	}
	/*	ignore all this
		else if (list.next == null) {
		//		System.out.println(node);
				if(mag.compareTo(current.magazine)<0) {
					System.out.println(node.magazine +" is less than " + current.magazine);
				//	node.next = list;
				//	temp = current;
					current = node;
					current.next = temp;
					System.out.println(current.magazine + "\n" + current.next.magazine);
				}
				else if(mag.compareTo(current.magazine)>0) {
					System.out.println(node.magazine+" is greater than " + current.magazine);
					current.next = node;
				//	temp = current.next;
				//	current.next = node;
				//	node.next = temp;
				}
				else
					System.out.println("already entered");
		}
	
		else {
			
			MagazineNode prev;
			
			while(current.next != null) {	
			
				if(mag.compareTo(current.magazine)<0) {
					System.out.println(node.magazine +" is less than " + current.magazine);
					prev = current;
					current = current.next;
			//		temp = current;
				//	current = node;
				//	node.next = temp;
				}
				else if(mag.compareTo(current.magazine)>0) {
					System.out.println(node.magazine+" is greater than " + current.magazine);
					prev = current;
					current = current.next;
				//	temp = current.next;
				//	current.next = node;
				//	node.next = temp;
				}
				
				prev = current;
				current = current.next;
			//	else
			//		System.out.println("already entered");
			}
		}
	}
	//	*/
	
	
	public String toString() {
		String result = "";
		
		MagazineNode current = list;
		while(current != null) {
			result += ""+current.magazine + "\n";
			current = current.next;
		}
		
		return result;
	}
	
		
	private class MagazineNode{
		public Magazine magazine;
		public MagazineNode next;
		
		public MagazineNode(Magazine mag) {
			magazine = mag;
			next = null;
		}
	}
}
