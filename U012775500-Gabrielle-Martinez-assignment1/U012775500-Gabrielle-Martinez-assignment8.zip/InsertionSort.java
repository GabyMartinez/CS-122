//PP 13.4 Driver Class
public class InsertionSort {
	 public static void main(String[]args){
		 IntList list = new IntList();
		 
		 list.insertionSort(5);
		 list.insertionSort(2);
		 System.out.println(list);
	 }
}
