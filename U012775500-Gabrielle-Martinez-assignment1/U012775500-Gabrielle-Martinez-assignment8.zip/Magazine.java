// PP 13.2
public class Magazine implements Comparable
{
	private String title;
	
	public Magazine(String title) {
		this.title = title;
	}
	
	public String getTitle() {
		return title;
	}

	@Override
	public int compareTo(Object arg0) {
		Magazine mag2 = (Magazine)arg0;
	//	if(title.equals(mag2.getTitle()))
			
		if (title.compareTo(mag2.getTitle())<0) {
			System.out.println("less than");
			return -1;
		}
		else if (title.compareTo(mag2.getTitle())>0) {
			System.out.println("greater than");
			return 1; 
		}
		else {
			System.out.println("equal");
			return 0;
		}
			
	}
	
	public String toString() {
		return title;
	}
	
}
