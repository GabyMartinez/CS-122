public class IntList { //PP 13.4
	private IntNode front; //first node in list
	//-----------------------------------------
	// Constructor. Initially list is empty.
	//-----------------------------------------
	public IntList()
	{
		//Your code here: create an empty list
		front=null;
	}
	//-----------------------------------------
	// Adds given integer to front of list.
	//-----------------------------------------
	public void addToFront(int val)
	{
		front = new IntNode(val,front);
	}
	//-----------------------------------------
	// Adds given integer to end of list.
	//-----------------------------------------
	public void addToEnd(int val)
	{
		IntNode newnode = new IntNode(val,null);
		
		// Your code here: if list is empty, this will be 		// the only node in it 
		if(front==null)
			front = newnode;
		else //add the node to the end
		{
			IntNode temp = front;
			//Your code here: make temp point to last thing in list
			while (temp.next!= null)
				temp = temp.next;
			//Your code here: now it is time to link the new node into list
			temp.next=newnode;
		}
	}
	//-----------------------------------------
	// Removes the first node from the list.
	// If the list is empty, does nothing.
	//-----------------------------------------
	public void removeFirst()
	{
		if (front != null)
			front = front.next;
	}
	//------------------------------------------------
	// Prints the list elements from first to last.
	//------------------------------------------------
	public void print()
	{
		System.out.println("--------------------");
		System.out.print("List elements: ");
		IntNode temp = front;
		// Your code here: iterate the entire list 
		while (temp!=null)
		{
			System.out.print(temp.val + " ");
			temp = temp.next;
		}
		System.out.println("\n-----------------------\n");
	}
	public int length() {
		int count=0;
		IntNode temp = front;
		// Your code here: iterate the entire list 
		while (temp!=null)
		{
			count++;
			temp = temp.next;
		}
		return count;
	}
	public String toString() {
		
		String result = "List elements: ";
		IntNode temp = front;
		// Your code here: iterate the entire list 
		while (temp!=null)
		{
			result = result+ " "+ temp.val + " ";
			temp = temp.next;
		}
		return result;
	}
	public void removeLast() {
		IntNode temp = front;
		IntNode prev = front;
		if(front.next==null)
			front = null;
		else //remove the node to the end
		{
			while (temp != null) {
				prev = temp;
				temp = temp.next;
				
			}
			prev.next = null;
		}		
	}
//*	
	public void insertionSort (int val){
		IntNode current = front, prev = front;
		IntNode node = new IntNode(val, null);
		
		if(front==null)
			front = node;
		else if(front.next==null) {
			if(node.val < current.val) {
				node.next = current;
				front = node;
			}
			else if(node.val > current.val) {
				current.next = node;
			}
		}
		else {
			while(current.next != null) {
				if(node.val < current.val) {
					node.next = current;
					prev.next = node;
				}
				else if(node.val > current.val) {
					node.next = current.next;
					current.next = node;
				}
				prev = current;
				current = current.next;
			}
		}
	}
//*/
	//*************************************************************
	// An inner class that represents a node in the integer list.
	// The public variables are accessed by the IntList class.
	//*************************************************************
	private class IntNode// implements Comparable
	{
		public int val; //value stored in node
		public IntNode next; //link to next node in list
		//------------------------------------------------------------------
		// Constructor; sets up the node given a value and IntNode reference
		//------------------------------------------------------------------
		public IntNode(int val, IntNode next)
		{
			this.val = val;
			this.next = next;
		}
	/*	@Override
		public int compareTo(Object arg0) {
			IntNode a = 
			return 0;
		}
	*/	
	}
}
