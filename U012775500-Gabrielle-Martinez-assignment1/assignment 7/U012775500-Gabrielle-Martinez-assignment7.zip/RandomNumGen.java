package application;

import java.util.Random;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RandomNumGen extends Application {//PP 4.12
	Random gen = new Random();
	int randNum;
	Text num;
	public void start(Stage primaryStage) {
		
			Pane root = new Pane();
			Label title = new Label("Random Number Generator");
		//	title.layoutXProperty().bind(root.widthProperty().divide(3));;
			title.setLayoutX(5);
			title.setLayoutY(10);
			title.setFont(Font.font("Raleway", FontWeight.BOLD, 40));
			
			Label subtitle = new Label("Any number between 1 and 100");
			subtitle.setLayoutY(70);
			subtitle.layoutXProperty().bind(root.widthProperty().divide(4));
			subtitle.setFont(Font.font("Raleway", FontWeight.MEDIUM, 20));
			
			
			Button generator = new Button("GENERATOR");
			generator.setFont(Font.font("Raleway", FontWeight.EXTRA_BOLD, 35));
			generator.layoutXProperty().bind(root.widthProperty().add(50).divide(4));
			generator.setLayoutY(150);
			generator.setOnMouseClicked(this::processMouseClick);
			
		//	randNum = gen.nextInt(101);
			num = new Text("Random Number: __");
			num.setFont(Font.font("Raleway", FontWeight.SEMI_BOLD, 30));
			num.setLayoutY(300);
			num.layoutXProperty().bind(root.widthProperty().divide(4));
			
			root.getChildren().addAll(title, subtitle, generator, num);
			
			Scene scene = new Scene(root,550,350);
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
		
	}
	public void processMouseClick(MouseEvent event) {
		randNum = gen.nextInt(100)+1;
		num.setText("Random Number: " + randNum);
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
