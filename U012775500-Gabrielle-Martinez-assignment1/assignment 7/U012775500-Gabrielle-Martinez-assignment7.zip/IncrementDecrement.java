package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class IncrementDecrement extends Application {//PP 4.14
	private Button increment, decrement;
	private Text num;
	private int number = 50;
	
	public void start(Stage primaryStage) {
		
			Pane root = new Pane();
			increment = new Button("Increment");
			increment.setLayoutX(10);
			increment.setLayoutY(50);
			increment.setFont(Font.font("Raleway", 20));
			increment.setOnMouseClicked(this::processMouseClick);
						
			decrement = new Button("Decrement");
			decrement.setLayoutX(160);
			decrement.setLayoutY(50);
			decrement.setFont(Font.font("Raleway", 20));
			decrement.setOnMouseClicked(this::processMouseClick);
			
			num = new Text("Number: 50");
			num.setLayoutX(95);
			num.setLayoutY(150);
			num.setFont(Font.font("Raleway", 20));
			
			root.getChildren().addAll(increment, decrement, num);
						
			Scene scene = new Scene(root,300,200);
			primaryStage.setResizable(false);
			primaryStage.setScene(scene);
			primaryStage.show();
		
	}
	
	public void processMouseClick(MouseEvent event) {
		
		if(event.getSource() == increment) {
			number++;
			num.setText("Number: "+number);
		}
		else {
			number--;
			num.setText("Number: "+number);
		}
			
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
