package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.application.Application;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class ViewPort extends Application{//PP 4.11
	public void start(Stage primaryStage) {
		
			Pane root = new Pane();
			Image img = new Image("https://cdn.dribbble.com/users/1149369/screenshots/3696287/untitled-3_1x.jpg");
			ImageView box1 = new ImageView(img);
			box1.setLayoutY(30);
			
			ImageView box2 = new ImageView(img);
			box2.setViewport(new Rectangle2D(150,100,100,100));
			box2.setLayoutY(360);
			
			Label og = new Label("Original:");
			og.setFont(Font.font("Century Gothic", FontWeight.BOLD, 20));
			og.setTextFill(Color.CORAL);
			
			Label icon = new Label("Icon:");
			icon.setTextFill(Color.CORAL);
			icon.setFont(Font.font("Century Gothic", FontWeight.BOLD, 20));
			icon.setLayoutY(330);
			
			root.getChildren().addAll(box1, box2, icon, og);
			
			Scene scene = new Scene(root,600,600);
			primaryStage.setScene(scene);
			primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
