package application;

import java.util.Random;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class RandCircle extends Application {//PP 4.13
	private Random gen = new Random();
	private Button btn;
	private Circle circle;
	public void start(Stage primaryStage) {
	
			BorderPane root = new BorderPane();
			Pane center = new Pane();
			
			circle = new Circle(50);
			circle.setCenterX(200);
			circle.setCenterY(200);
			
			center.getChildren().add(circle);
			
			btn = new Button("Move Circle");
			btn.setFont(Font.font("Raleway", 20));
			btn.setLayoutX(140);
			btn.setOnMouseClicked(this::processMouseClick);
					
			Pane bottom = new Pane();
		//	bottom.setOpaqueInsets(new Insets(0, 20, 10, 20));
			bottom.getChildren().add(btn);
			
			root.setBottom(bottom);
			root.setCenter(center);
			
			Scene scene = new Scene(root,400,400);
			
			primaryStage.setScene(scene);
			primaryStage.show();
		
	}
	public void processMouseClick(MouseEvent event) {
		int randX = gen.nextInt(300);
		int randY = gen.nextInt(300);
		circle.setCenterX(randX);
		circle.setCenterY(randY);
	}
	
	public static void main(String[] args) {
		launch(args);
	}

}
