//PP 10.1
//I don't think I understand the question. 
//Is the interface supposed to link all the other classes instead of inheritance?
public interface Payable {
	public void payday();
	//10.2
	public void vacation();
}
