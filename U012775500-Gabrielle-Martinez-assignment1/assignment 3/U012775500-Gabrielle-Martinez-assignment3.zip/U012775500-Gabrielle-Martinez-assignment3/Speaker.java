//PP 10.3
public interface Speaker {
	public void speak();
	public void announce(String str);
}
