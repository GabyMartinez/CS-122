package application;

public class StringNotAcceptedException extends Exception
{
	public StringNotAcceptedException(String message) {
		System.out.println(message);
	}
}
