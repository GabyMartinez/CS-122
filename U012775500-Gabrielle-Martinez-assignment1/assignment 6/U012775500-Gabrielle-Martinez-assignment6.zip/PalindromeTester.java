import java.util.Scanner;
public class PalindromeTester { //PP 12.1
	public static boolean isPalindrome(String str) {
		if(str.length() == 0 || str.length() == 1)
            // if length =0 OR 1 then it is
            return true; 
		
		if(str.charAt(0) == str.charAt(str.length()-1))
			//	define palindrome:
			//	first letter == last letter
			//	first letter -1 (second letter) = last letter -1(second to last letter)
			return isPalindrome(str.substring(1, str.length()-1)); //recursive
			//radar			atlanta
			//01234			0123456
			//r ada r		a tlant a
			//  012			  01234
			//r a d a r		a t lan t a
			//    0			    012
			//true			false
		
		else
			return false;
	}
	
	//try atlanta and radar
	public static void main(String[]args) {
		Scanner scan = new Scanner(System.in);
		String str, another = "y";
		//int left, right;
		
		while(another.equalsIgnoreCase("y")) {
			System.out.println("Enter potential palindrome: ");
			str = scan.nextLine();
			
			if(PalindromeTester.isPalindrome(str)) {
				System.out.println("Palindrome\n");
			}
			else System.out.println("NOT palindrome");
			
			System.out.print("Test another string? (y/n)");
			another = scan.nextLine();
		}
		
		
	/*	while(another.equalsIgnoreCase("y")) {
			System.out.println("Enter potential palindrome: ");
			str = scan.nextLine();
			
			left = 0;
			right = str.length()-1;
			
			while(str.charAt(left) == str.charAt(right) && left<right) {
				left++;
				right--;
			}
			System.out.println();
			
			if(left<right) {
				System.out.println("NOT palindrome");
			}
			else System.out.println("Palindrome\n");
			
			System.out.print("Test another string? (y/n)");
			another = scan.nextLine();
		}
	 */		
	}
}
