import java.util.Scanner;
public class DivisorCalc {
	
	public static int gcd(int num1, int num2) {
		if (num2 % num1 == 0)
			return num1;
		
		else 
			return gcd(num2, (num1 % num2));//recursive
		//keeps looping until num1 divides into num2 evenly
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan =  new Scanner(System.in);
		int a, b;
		System.out.print("Enter two numbers (with a space): ");
		a = scan.nextInt();
		b = scan.nextInt();
		
	//	int c = a%b;
	//	System.out.print(c);
		System.out.println(DivisorCalc.gcd(a, b) + " is the GCD");
	}

}
